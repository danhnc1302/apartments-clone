Please use gopkg.in/fsnotify.v0 instead.

For updates, see: https://fsnotify.org/
