/*
Source code and other details for the project are available at GitHub:

   https://github.com/kataras/sitemap

Current Version

0.0.6

Installation

The only requirement is the Go Programming Language:

    $ go get github.com/kataras/sitemap

Examples

   https://github.com/kataras/sitemap/tree/master/_examples
*/

package sitemap
