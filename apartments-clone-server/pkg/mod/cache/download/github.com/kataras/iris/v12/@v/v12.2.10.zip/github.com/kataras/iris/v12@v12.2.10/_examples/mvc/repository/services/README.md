# Service Layer

The package which has access to call functions from the "repositories" and "models" ("datamodels" only in that simple example). It should contain the domain logic.