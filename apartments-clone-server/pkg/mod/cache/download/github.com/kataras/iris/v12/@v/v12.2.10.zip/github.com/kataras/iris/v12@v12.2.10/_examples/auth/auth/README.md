# Auth Package (+ Single Sign On)

```sh
$ go run .
```

1. GET/POST: http://localhost:8080/signin
2. GET: http://localhost:8080/member
3. GET: http://localhost:8080/owner
4. POST: http://localhost:8080/refresh
5. GET: http://localhost:8080/signout
6. GET: http://localhost:8080/signout-all