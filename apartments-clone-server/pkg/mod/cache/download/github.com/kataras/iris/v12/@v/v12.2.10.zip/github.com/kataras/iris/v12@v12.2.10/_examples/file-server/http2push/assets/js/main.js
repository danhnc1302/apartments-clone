console.log("example");

function onClick() {
    window.alert("button clicked");
}