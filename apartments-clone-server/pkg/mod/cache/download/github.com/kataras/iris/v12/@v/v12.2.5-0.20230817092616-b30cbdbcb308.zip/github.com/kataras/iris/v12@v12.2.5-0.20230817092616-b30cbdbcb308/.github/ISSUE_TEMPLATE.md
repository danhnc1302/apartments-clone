Examples for the Iris project can be found at
<https://github.com/kataras/iris/tree/master/_examples>.

Documentation for the Iris project can be found at
<https://www.iris-go.com/docs>.

Love iris? Please consider supporting the project:
👉  https://iris-go.com/donate

Care to be part of a larger community? Fill our user experience form:
👉  https://goo.gl/forms/lnRbVgA6ICTkPyk02
