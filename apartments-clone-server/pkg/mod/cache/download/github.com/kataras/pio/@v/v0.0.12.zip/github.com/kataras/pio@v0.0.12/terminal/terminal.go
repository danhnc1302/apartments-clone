package terminal

// SupportColors reports whether a windows terminal platform can support 256 colors.
// See terminal_windows.go#init for further details.
var SupportColors = true
