// Package awsrulesfn provides AWS focused endpoint rule functions for
// evaluating endpoint resolution rules.
package awsrulesfn
