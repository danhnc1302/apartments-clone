// Package io provides utilities for Smithy generated API clients.
package io
